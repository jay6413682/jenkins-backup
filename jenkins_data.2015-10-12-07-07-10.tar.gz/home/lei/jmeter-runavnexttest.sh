#Git pull
cd /root/git/RallyAutomation2
echo "### switch remote to ssh ###"
git remote set-url origin git@github.com:mudynamics/RallyAutomation2.git
REMOTE_REP=`git remote -v`
echo "### The remote origin is: $REMOTE_REP ###"

echo "### Git checkout ###"
git checkout rallyNotifier
echo "### Git pull; this will use key in /root/.ssh which is ~/.ssh for root user ###"
git pull origin


#!/bin/bash
echo "### Running JMeter performance test ###"

# Clear out old results
rm /home/lei/RunAVNextTest.jtl

# Run the tests
echo "## Running the tests"
cd "/root/git/RallyAutomation2/Tools"

jmeter -n -t test.jmx -l /home/lei/RunAVNextTest.jtl -JRunAVNextTest=true -JCreateSubnet=false -JTestConfigPath=/root/git/RallyAutomation2/Tools

echo "RunAVNextTest.jtl is generated at /home/lei/"
