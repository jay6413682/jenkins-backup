#!/bin/sh
LOCALREPO="/root/git/jenkins-backup"
GITHOME="/root/git"
# We do it this way so that we can abstract if from just git later on
LOCALREPO_VC_DIR=$LOCALREPO/.git
if [ ! -d $LOCALREPO_VC_DIR ]
then
	echo "make dir jenkins-backup"
	mkdir $GITHOME/jenkins-backup
	echo "git init"
	git init
fi

LOCALHOME=/home/lei

NOW=$(date +"%Y-%m-%d-%H-%M-%S")
DUMP=jenkins_data.$NOW.tar.gz
JENKINS_HOME=/var/lib/jenkins
echo "compress jenkins folder"
#nice -n 19 tar --exclude-from $LOCALHOME/jenkins_backup_exclusions -zcf $LOCALREPO/$DUMP $JENKINS_HOME
#nice -n 19 tar --files-from $LOCALHOME/jenkins_backup_inclusion -zcf $LOCALREPO/$DUMP
nice -n 19 tar -cvzf $LOCALREPO/$DUMP $(cat $LOCALHOME/jenkins_backup_inclusion)
FILEZIZE=`ls -l $LOCALREPO/$DUMP | cut -d' ' -f5`
echo "The size of file $DUMP is $FILEZIZE"
if [ $FILEZIZE -gt 100000000 ] 
then
	echo "The size of compressed file $DUMP is greater than 100M"
	exit 1
fi
REPOSRC="git@github.com:jay6413682/jenkins-backup.git"

cd $LOCALREPO
echo "git add"
git add .
echo "git commit"
git commit -m "jenkins backup"
echo "git remote add origin"
git remote add origin $REPOSRC
echo "git remote -v"
git remote -v
echo "git push"
git push origin master

echo "remove files in jenkins-backup folder"
git rm $LOCALREPO/*
echo "git commit"
git commit -m "remove $DUMP"

# End

